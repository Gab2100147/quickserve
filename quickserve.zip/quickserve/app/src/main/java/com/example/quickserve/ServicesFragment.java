package com.example.quickserve;

import android.content.Intent;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;

public class ServicesFragment extends Fragment {
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_services, container, false);
        Spinner spinner = view.findViewById(R.id.service_spinner);
        Button proceedButton = view.findViewById(R.id.btnGo);

        // Array of services
        String[] services = {
                "Select a Service",
                "Barangay Clearance",
                "Certificate of Residency",
                "Business Permit",
                "Indigency Certificate"
        };

        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(), android.R.layout.simple_spinner_dropdown_item, services);
        spinner.setAdapter(adapter);

        // Set up the button click listener
        proceedButton.setOnClickListener(v -> {
            String selectedService = spinner.getSelectedItem().toString();
            if (!selectedService.equals("Select a Service")) {
                Intent intent = new Intent(getActivity(), CertificateActivity.class);
                intent.putExtra("CERT_TYPE", selectedService);
                startActivity(intent);
            } else {
                Toast.makeText(getContext(), "Please select a service", Toast.LENGTH_SHORT).show();
            }
        });

        return view;
    }
}
